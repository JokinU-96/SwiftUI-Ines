//
//  ContentView.swift
//  Calculadora
//
//  Created by  on 10/3/25.
//

import SwiftUI

var calculadoraArray: [[String]] = [
    ["7", "8", "9", "÷"],
    ["4", "5", "6", "x"],
    ["1", "2", "3", "-"],
    ["AC", "0", ",", "+"],
]

var containerWidth: CGFloat = UIScreen.main.bounds.width - 32.0
var containerHWidth: CGFloat = UIScreen.main.bounds.width - 32.0

struct ContentView: View {

    @State private var operacion = "0"
    @State private var resultado = ""
    @Environment(\.verticalSizeClass) var sizeClass
    //@ObservedObject var viewModel = TaskViewModel()

    var body: some View {
        if sizeClass == .regular {
            VStack {
                VStack{
                    Text(operacion)
                        .font(.largeTitle)
                        .fontDesign(.rounded)
                        .padding(.horizontal)
                    Text(resultado)
                        .font(.largeTitle)
                        .fontDesign(.rounded)
                }
                .frame(width: containerWidth * 0.85, height: 100, alignment: .trailing)
                .multilineTextAlignment(.trailing)
                .background(.gray)
                .cornerRadius(5)
                
                
                ForEach(0..<4) { index_a in
                    HStack {
                        ForEach(0..<4) { index_b in
                            Button(action: {
                                botonPulsado(calculadoraArray[index_a][index_b])
                            }) {
                                Text(calculadoraArray[index_a][index_b])
                                    .foregroundColor(.black)
                            }
                            .frame(width: 50, height: 50)
                            .background(index_b == 3 ? Color.orange : Color.white)
                            .cornerRadius(30)
                        }
                    }
                }
                Button(action: {
                    botonPulsado("=")
                }) {
                    Text("=")
                        .foregroundColor(.black)
                }
                .frame(width: 50, height: 50)
                .background(.orange)
                .cornerRadius(30)

            }
            .padding()
        } else {
            VStack {
                
                VStack{
                    Text(operacion)
                        .font(.largeTitle)
                        .fontDesign(.rounded)
                        .padding(.horizontal)
                    Text(resultado)
                        .font(.largeTitle)
                        .fontDesign(.rounded)
                }
                .frame(width: containerHWidth * 0.85, height: 100, alignment: .trailing)
                .multilineTextAlignment(.trailing)
                .background(.gray)
                .cornerRadius(5)
                
                
                ForEach(0..<4) { index_a in
                    HStack {
                        ForEach(0..<4) { index_b in
                            Button(action: {
                                botonPulsado(calculadoraArray[index_a][index_b])
                            }) {
                                Text(calculadoraArray[index_a][index_b])
                                    .foregroundColor(.black)
                            }
                            .frame(width: (containerHWidth * 0.8)/4, height: 30)
                            .background(index_b == 3 ? Color.orange : Color.white)
                            .cornerRadius(30)
                        }
                    }
                }
                Button(action: {
                    botonPulsado("=")
                }) {
                    Text("=")
                        .foregroundColor(.black)
                }
                .frame(width: containerHWidth * 0.825, height: 30)
                .background(.orange)
                .cornerRadius(30)
            }
        }
    }

    func botonPulsado(_ botonTexto: String) {
        
        switch botonTexto {
        case "+":
            operacion = operacion + botonTexto
        case "-":
            operacion = operacion + botonTexto
        case "x":
            operacion = operacion + botonTexto
        case "÷":
            operacion = operacion + botonTexto
        case "=":
            var ex = operacion.replacingOccurrences(of: ",", with: ".")
            ex = ex.replacingOccurrences(of: "x", with: "*")
            ex = ex.replacingOccurrences(of: "÷", with: "/")
            operacion =
            String(
                calcular(expresion: ex)
            ).replacingOccurrences(of: ".", with: ",")
            resultado =
            String(
                calcular(expresion: ex)
            ).replacingOccurrences(of: ".", with: ",")
            
        case "AC":
            operacion = ""
            resultado = ""
        default:
            operacion = operacion + botonTexto

        }
    }
    func calcular(expresion: String) -> String {
        var nums: [Double] = []
        var ops: [Character] = []
        var numStr = ""
        

        for char in expresion {

            switch char {
            case "+":
                ops.append(char)
                let num = Double(numStr)!
                nums.append(num)
                numStr = ""
            case "-":
                ops.append(char)
                let num = Double(numStr)!
                nums.append(num)
                numStr = ""
            case "*":
                ops.append(char)
                let num = Double(numStr)!
                nums.append(num)
                numStr = ""
            case "/":
                ops.append(char)
                let num = Double(numStr)!
                nums.append(num)
                numStr = ""
            default:
                numStr = numStr + String(char)
            }
        }
        
        let num = Double(numStr)!
        nums.append(num)
        
        var res = 0.0
        
        for op in ops {
            if op == "*" {
                let ind = ops.firstIndex(of: op)
                let indN = Int(ind!)
                res = nums[indN] * nums[indN + 1]
                nums[indN] = res
                nums.remove(at: indN + 1)
                ops.remove(at: indN)
            }
            if op == "/" {
                let ind = ops.firstIndex(of: op)
                let indN = Int(ind!)
                if nums[indN + 1] == 0{
                    return "N/A"
                }else{
                    res = nums[indN] / nums[indN + 1]
                }
                nums[indN] = res
                nums.remove(at: indN + 1)
                ops.remove(at: indN)
            }
        }
        
        for op in ops {
            if op == "+" {
                let ind = ops.firstIndex(of: op)
                let indN = Int(ind!)
                res = nums[indN] + nums[indN + 1]
                nums[indN] = res
                nums.remove(at: indN + 1)
                ops.remove(at: indN)
            }
            if op == "-" {
                let ind = ops.firstIndex(of: op)
                let indN = Int(ind!)
                res = nums[indN] - nums[indN + 1]
                nums[indN] = res
                nums.remove(at: indN + 1)
                ops.remove(at: indN)
            }
        }
        return String(format:"%.3f", res)
    }
}

#Preview {
    ContentView()
}
