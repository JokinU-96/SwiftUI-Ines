//
//  CalculadoraApp.swift
//  Calculadora
//
//  Created by  on 10/3/25.
//

import SwiftUI

@main
struct CalculadoraApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
