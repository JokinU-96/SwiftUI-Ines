# Calculadora básica

Crea una calculadora básica.

## Requisitos

El interfaz de usuario deberá tener este aspecto:

<img src="./calculadora1.jpg" title="" alt="ios-app-calculadoraIMC.png" width="173">

<img title="" src="./calculadora2.jpg" alt="calculadora2.jpg" width="412">



## Requisitos técnicos

- Requisitos técnicos:

- Proyecto de tipo iOS App

- Aplicación desarrollada en SwiftUI con estructura MVVM

- Utilizar *Stack Views* para agrupar los elementos

- Orientación vertical y horizontal

## Lógica de la aplicación

- La aplicación se inicia a 0 o cuando se presiona AC también empieza en 0.

- El usuario puede ir presionando los botones para realizar la operación que quiera, y esta se irá mostrando en pantalla. 

- Una vez se le da al botón de =, muestra en gris la última operación realizada con el resultado abajo. 

- Si se sigue operando se hace sobre el resultado anterior.
